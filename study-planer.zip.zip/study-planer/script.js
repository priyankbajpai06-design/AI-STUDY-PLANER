// ELEMENTS
const addBtn = document.getElementById("addBtn");
const timeBtn = document.getElementById("timeBtn");
const goalBtn = document.getElementById("goalBtn");
const startBtn = document.getElementById("startBtn");
const resetBtn = document.getElementById("resetBtn");

const subjectInput = document.getElementById("subjectInput");
const prioritySelect = document.getElementById("priority");
const subjectsDiv = document.getElementById("subjects");

const startTimeInput = document.getElementById("startTime");
const endTimeInput = document.getElementById("endTime");
const timetableDiv = document.getElementById("timetable");

const goalInput = document.getElementById("goalInput");
const goalDisplay = document.getElementById("goalDisplay");
const doneHours = document.getElementById("doneHours");
const progressBar = document.getElementById("progressBar");

const timerDisplay = document.getElementById("timer");
const streakDisplay = document.getElementById("streak");

const taskInput = document.getElementById("taskInput");
const taskList = document.getElementById("taskList");

const canvas = document.getElementById("graphCanvas");
const ctx = canvas.getContext("2d");

const todoSection = document.getElementById("todoSection");
const graphSection = document.getElementById("graphSection");

// DATA
let subjects = JSON.parse(localStorage.getItem("subjects")) || [];
let tasks = JSON.parse(localStorage.getItem("tasks")) || [];
let history = JSON.parse(localStorage.getItem("history")) || [];

let done = 0;
let time = 1500;
let timerInterval;

// EVENTS
addBtn.onclick = addSubject;
timeBtn.onclick = generateTimetable;
goalBtn.onclick = setGoal;
startBtn.onclick = startTimer;
resetBtn.onclick = resetTimer;

// TIME FUNCTIONS
function parseTime(input){
  input = input.toLowerCase().trim();
  let isPM = input.includes("pm");
  let isAM = input.includes("am");

  input = input.replace("am","").replace("pm","").trim();
  let parts = input.split(":");

  let h = parseInt(parts[0]) || 0;
  let m = parts[1] ? parseInt(parts[1]) : 0;

  if(isPM && h<12) h+=12;
  if(isAM && h===12) h=0;

  return h*60 + m;
}

function formatTime(min){
  let h = Math.floor(min/60);
  let m = min%60;
  let ampm = h>=12?"PM":"AM";
  h = h%12 || 12;
  return `${h}:${m<10?"0":""}${m} ${ampm}`;
}

// **UPDATED FLEXIBLE TIMETABLE FUNCTION**
function generateTimetable(){
  let startInput = startTimeInput.value.trim();
  let endInput = endTimeInput.value.trim();
  
  if(!startInput || !endInput) {
    return alert("Start aur End time daalo!");
  }
  
  let start = parseTime(startInput);
  let end = parseTime(endInput);
  
  if(!start || !end) {
    return alert("Time format: HH:MM AM/PM (jaise 9:00 AM)");
  }
  
  // 24 hours cycle
  start = start % (24*60);
  end = end % (24*60);
  
  // Calculate total minutes (same day or overnight)
  let total;
  if(end > start) {
    total = end - start; // Same day
  } else if(end < start) {
    total = (24*60 - start) + end; // Overnight
  } else {
    return alert("Start aur End time same nahi ho sakta!");
  }
  
  if(total < 30) {
    return alert("Kam se kam 30 minutes ka gap do!");
  }

  let totalP = subjects.reduce((s,x)=>s+parseInt(x.priority),0);
  if(totalP === 0) return alert("Pehle subjects add karo!");

  let cur = start, out = [];
  subjects.forEach(s=>{
    let mins = Math.max(15, Math.round((parseInt(s.priority)/totalP)*total));
    let next = cur + mins;
    
    // Handle overnight display
    let displayNext = next >= 24*60 ? next - 24*60 : next;
    
    out.push(`${formatTime(cur)} - ${formatTime(displayNext)} → ${s.name}`);
    cur = next;
  });

  // Show total duration
  let totalHrs = Math.floor(total/60);
  let totalMins = total%60;
  timetableDiv.innerHTML = `
    <h4>📚 Study Plan (${formatTime(start)} - ${formatTime(end)})</h4>
    <p><strong>Total: ${totalHrs}h ${totalMins}m</strong></p>
    ${out.map(x=>`<p style="margin:5px 0;">${x}</p>`).join("")}
  `;
}

// SUBJECTS
function displaySubjects(){
  subjectsDiv.innerHTML = subjects.map((s,i)=>
    `<p>${s.name}(P:${s.priority})
    <button onclick="deleteSubject(${i})">❌</button></p>`
  ).join("");

  addBtn.disabled = subjects.length >= 10;
}

function addSubject(){
  if(subjects.length >= 10) return alert("Max 10 subjects");

  let name = subjectInput.value.trim();
  let p = prioritySelect.value;

  if(!name) return alert("Enter subject");

  subjects.push({name,priority:p});
  localStorage.setItem("subjects",JSON.stringify(subjects));
  subjectInput.value="";
  displaySubjects();
}

function deleteSubject(i){
  subjects.splice(i,1);
  localStorage.setItem("subjects",JSON.stringify(subjects));
  displaySubjects();
}

// GOAL
function setGoal(){
  goalDisplay.innerText=goalInput.value;
  localStorage.setItem("goal",goalInput.value);
}

// TIMER
function startTimer(){
  if(timerInterval) return;
  timerInterval=setInterval(()=>{
    let m=Math.floor(time/60);
    let s=time%60;
    timerDisplay.innerText=`${m}:${s<10?"0":""}${s}`;
    time--;
    if(time<0){
      clearInterval(timerInterval);
      timerInterval=null;
      alert("Break time");
      addStudyHour();
      time=1500;
    }
  },1000);
}

function resetTimer(){
  clearInterval(timerInterval);
  timerInterval=null;
  time=1500;
  timerDisplay.innerText="25:00";
}

// PROGRESS
function addStudyHour(){
  done++;
  let goal=localStorage.getItem("goal")||1;
  doneHours.innerText=done;
  progressBar.style.width=(done/goal*100)+"%";
}

// STREAK
function updateStreak(){
  let today=new Date().toDateString();
  let last=localStorage.getItem("last");
  if(last!==today){
    let s=localStorage.getItem("streak")||0;
    s++;
    localStorage.setItem("streak",s);
    localStorage.setItem("last",today);
  }
  streakDisplay.innerText=localStorage.getItem("streak")||0;
}

// TODO
function addTask(){
  let t=taskInput.value;
  if(!t) return;
  tasks.push({name:t,done:false});
  localStorage.setItem("tasks",JSON.stringify(tasks));
  taskInput.value="";
  displayTasks();
}

function displayTasks(){
  taskList.innerHTML=tasks.map((t,i)=>
    `<p>
    <span style="text-decoration:${t.done?"line-through":"none"}">${t.name}</span>
    <button onclick="toggleTask(${i})">✔</button>
    </p>`).join("");
  updateGraph();
}

function toggleTask(i){
  tasks[i].done=!tasks[i].done;
  localStorage.setItem("tasks",JSON.stringify(tasks));
  displayTasks();
}

// GRAPH
function updateGraph(){
  let total=tasks.length;
  let doneC=tasks.filter(t=>t.done).length;
  let percent=total?Math.round(doneC/total*100):0;

  let today=new Date().toDateString();
  let saved=localStorage.getItem("graphDay");

  if(saved!==today){
    history.push(percent);
    if(history.length>7) history.shift();
    localStorage.setItem("history",JSON.stringify(history));
    localStorage.setItem("graphDay",today);
  }

  drawGraph();
}

function drawGraph(){
  ctx.clearRect(0,0,canvas.width,canvas.height);
  if(history.length===0) return;

  let step=canvas.width/(history.length-1||1);

  ctx.beginPath();
  history.forEach((h,i)=>{
    let x=i*step;
    let y=canvas.height-(h/100)*canvas.height;
    i===0?ctx.moveTo(x,y):ctx.lineTo(x,y);
  });

  ctx.strokeStyle="#2563eb";
  ctx.lineWidth=3;
  ctx.stroke();
}

// SIDEBAR
function showSection(s){
  document.querySelectorAll(".panel").forEach(p=>p.classList.remove("active"));
  if(s==="todo") todoSection.classList.add("active");
  if(s==="graph") graphSection.classList.add("active");
}

// INIT
displaySubjects();
displayTasks();
drawGraph();
updateStreak();